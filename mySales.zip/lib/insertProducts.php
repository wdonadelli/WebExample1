<?php
$table  = "products";
$action = 0;
require "crud.php";
?>
