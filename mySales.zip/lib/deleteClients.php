<?php
$table  = "clients";
$action = 2;
require "crud.php";
?>
