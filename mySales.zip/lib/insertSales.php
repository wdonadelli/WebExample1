<?php
$table  = "sales";
$action = 0;
require "crud.php";
?>
