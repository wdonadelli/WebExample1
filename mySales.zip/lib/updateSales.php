<?php
$table  = "sales";
$action = 1;
require "crud.php";
?>
