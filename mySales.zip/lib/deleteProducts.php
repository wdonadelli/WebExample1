<?php
$table  = "products";
$action = 2;
require "crud.php";
?>
