<?php
$table  = "sales";
$action = 2;
require "crud.php";
?>
