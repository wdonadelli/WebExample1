<?php
$table  = "products";
$action = 1;
require "crud.php";
?>
