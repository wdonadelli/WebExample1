<?php
$table  = "clients";
$action = 0;
require "crud.php";
?>
