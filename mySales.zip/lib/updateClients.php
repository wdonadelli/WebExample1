<?php
$table  = "clients";
$action = 1;
require "crud.php";
?>
